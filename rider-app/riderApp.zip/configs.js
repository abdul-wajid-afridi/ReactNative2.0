
const configs = {
    endpoints: {
        
        // Remote
        server: "http://52.77.249.233:4004",
        static: `http://52.77.249.233:4004/static`,
        api: `http://52.77.249.233:4004`,

        // Local
        // server: "http://192.168.100.7:3001",
        // static: `http://192.168.100.7:3001/static`,
        // api: `http://192.168.100.7:3001`,
    },
    googleMap: {
        apiKey: "AIzaSyBCLOzJhFQVKwoWv3jFuAwiJHVCdWhED0w"
    }
}

export default configs;