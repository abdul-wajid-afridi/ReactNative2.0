export default {
  primary: "#FF9135",
  grey: "grey",

  success: "#28a745",
  danger: "#dc3545",
};
